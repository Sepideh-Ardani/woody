<?php
// idea.php

// اتصال به پایگاه داده
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_name = $_POST['order_name'];
    $order_date = $_POST['order_date'];
    $order_desc = $_POST['order_desc'];
    $cus_name = $_POST['cus_name'];
    $cus_email = $_POST['cus_email'];
    $cus_phone = $_POST['cus_phone'];

    // مدیریت فایل آپلود شده
    $order_img = null;
    if (isset($_FILES['order_img']) && $_FILES['order_img']['error'] == 0) {
        $upload_dir = 'photo/';  // پوشه آپلود
        $upload_file = $upload_dir . basename($_FILES['order_img']['name']);
        if (move_uploaded_file($_FILES['order_img']['tmp_name'], $upload_file)) {
            $order_img = $upload_file;
        } else {
            echo "مشکلی در بارگذاری فایل پیش آمد.";
            exit;
        }
    }

    // درج اطلاعات در جدول orders
    try {
        $stmt = $connection->prepare("INSERT INTO orders (order_name, order_date, order_desc, order_img, cus_name, cus_email, cus_phone) 
        VALUES (:order_name, :order_date, :order_desc, :order_img, :cus_name, :cus_email, :cus_phone)");
        $stmt->execute([
            ':order_name' => $order_name,
            ':order_date' => $order_date,
            ':order_desc' => $order_desc,
            ':order_img' => $order_img,
            ':cus_name' => $cus_name,
            ':cus_email' => $cus_email,
            ':cus_phone' => $cus_phone
        ]);

        echo '<script>alert("ایده با موفقیت ثبت شد")</script>';
    } catch (PDOException $e) {
        echo "خطا: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fa">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/idea.css" type="text/css" />
    <title>ثبت ایده جدید</title>
</head>

<body class="add">
    <div class="container-add">
        <h2 class="add-h2">ثبت ایده جدید</h2>
        <form action="idea.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="cus_name">نام مشتری:</label>
                <input type="text" id="cus_name" name="cus_name" placeholder="نام مشتری" required>
            </div>

            <div class="form-group">
                <label for="cus_email">ایمیل مشتری:</label>
                <input type="email" id="cus_email" name="cus_email" placeholder="ایمیل مشتری" required>
            </div>

            <div class="form-group">
                <label for="cus_phone">شماره تماس:</label>
                <input type="text" id="cus_phone" name="cus_phone" placeholder="شماره تماس" required>
            </div>

            <div class="form-group">
                <label for="order_name">عنوان ایده:</label>
                <input type="text" id="order_name" name="order_name" placeholder="عنوان ایده" required>
            </div>

            <div class="form-group">
                <label for="order_date">تاریخ ایده:</label>
                <input type="date" id="order_date" name="order_date" required>
            </div>

            <div class="form-group">
                <label for="order_img">عکس ایده:</label>
                <input type="file" id="order_img" name="order_img" required>
            </div>

            <div class="form-group">
                <label for="order_desc">توضیحات:</label>
                <textarea id="order_desc" name="order_desc" placeholder="توضیحات" required></textarea>
            </div>

            <button type="submit" class="add_btn" name="submit_order">ثبت</button>
        </form>
    </div>
</body>

</html>