<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

require_once 'config.php';

// گرفتن نام دسته‌بندی
$query = "SELECT p.*, c.cate_name FROM products p LEFT JOIN category c ON p.cate_id = c.cate_id";
$stmt = $connection->prepare($query);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت محصولات</title>
    <link rel="stylesheet" href="../style/bootstrap.rtl.min.css" />
    <style>
    .table thead {
        background-color: #4D869C;
        color: #EEF7FF;
    }

    .table tbody tr {
        background-color: #7AB2B2;
    }
    </style>
</head>

<body style="background-color:#4D869C;">
    <div class="container">
        <div class="row">
            <div class="col">
                <table class="table table-hover table-primary">
                    <thead>
                        <tr>
                            <th scope="col">شناسه محصول</th>
                            <th scope="col">نام محصول</th>
                            <th scope="col">دسته‌بندی</th>
                            <th scope="col">وضعیت</th>
                            <th scope="col">عکس محصول</th>
                            <th scope="col">قیمت محصول</th>
                            <th scope="col">توضیحات</th>
                            <th scope="col">عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product) { ?>
                        <tr>
                            <td scope="col"><?php echo htmlspecialchars($product['product_id']); ?></td>
                            <td scope="col"><?php echo htmlspecialchars($product['product_name']); ?></td>
                            <td scope="col"><?php echo htmlspecialchars($product['cate_name']); ?></td>
                            <td scope="col"><?php echo $product['product_statues'] == 1 ? 'موجود' : 'ناموجود'; ?></td>
                            <td scope="col"><img width="100" height="100"
                                    src="../pic/<?php echo htmlspecialchars($product['product_cover']); ?>" alt=""></td>
                            <td scope="col"><?php echo htmlspecialchars($product['product_price']); ?></td>
                            <td scope="col"><?php echo htmlspecialchars($product['product_description']); ?></td>
                            <td scope="col">
                                <a onclick="return confirm('آیا از حذف اطمینان دارید؟')" class="btn btn-danger"
                                    role="button"
                                    href="delete.php?id=<?php echo htmlspecialchars($product['product_id']); ?>">حذف</a>
                            </td>
                            <td scope="col">
                                <a class="btn btn-primary" role="button"
                                    href="update.php?id=<?php echo htmlspecialchars($product['product_id']); ?>">ویرایش</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>