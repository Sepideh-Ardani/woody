<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

require_once 'config.php';

$query = "SELECT * FROM customers";
$stmt = $connection->prepare($query);
$stmt->execute();
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت کاربران</title>
    <link rel="stylesheet" href="../style/bootstrap.rtl.min.css" />
    <style>
    .table thead {
        background-color: #4D869C;
        color: #EEF7FF;
    }

    .table tbody tr {
        background-color: #7AB2B2;
    }
    </style>
</head>

<body style="background-color:#4D869C;">
    <div class="container">
        <div class="row">
            <div class="col">
                <table class="table table-hover table-primary">
                    <thead>
                        <tr>
                            <th scope="col">شناسه کاربر </th>
                            <th scope="col">نام کاربر </th>
                            <th scope="col">تلفن کاربر</th>
                            <th scope="col">ایمیل کاربر</th>
                            <th scope="col">رمز عبور کاربر</th>
                            <th scope="col">آدرس کاربر</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($customers as $customer) { ?>
                        <tr>
                            <td scope="col"><?php echo htmlspecialchars($customer['cus_id']); ?></td>
                            <td scope="col"><?php echo htmlspecialchars($customer['cus_name']); ?></td>
                            <td scope="col"><?php echo htmlspecialchars($customer['cus_phone']); ?></td>
                            <td scope="col"><?php echo htmlspecialchars($customer['cus_email']); ?></td>
                            <td scope="col"><?php echo htmlspecialchars($customer['cus_pass']); ?></td>
                            <td scope="col"><?php echo htmlspecialchars($customer['cus_address']); ?></td>
                            <td scope="col">
                                <a onclick="return confirm('آیا از حذف اطمینان دارید؟')" class="btn btn-danger"
                                    role="button"
                                    href="delcontact.php?id=<?php echo htmlspecialchars($customer['cus_id']); ?>">حذف</a>
                            <td scope="col">
                                <a class="btn btn-primary" role="button"
                                    href="updatecontact.php?id=<?php echo htmlspecialchars($customer['cus_id']); ?>">ویرایش</a>
                            </td>
                            </td>
                            <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>