<?php
session_start();
require_once "config.php";

if(isset($_POST['login_btn'])){
    $email = $_POST['email'];
    $pass = md5($_POST['pass']);

    $query = "SELECT * FROM user WHERE user_email = '$email' AND user_pass = '$pass'";
    $stmt = $connection->prepare($query);
    $stmt->execute([$email, $pass]);
    $result = $stmt->fetch();
    $cusquery = "SELECT * FROM customers WHERE cus_email = '$email' AND cus_pass = '$pass'";
            $cusstmt = $connection->prepare($cusquery);
            $cusstmt->execute([$email, $pass]);
            $cusresult = $cusstmt->fetch();
    if(is_array($result)){
        if($result['user_role'] == 1){
            $_SESSION['user'] = 1;
            header("location:admin.php");
            echo '<script>alert(" به پنل ادمین خوش آمدید")</script>';
            exit;
        }
    } 
    elseif(is_array($cusresult)){
        $_SESSION['user'] = 0;
        header("location:../index.html");
        echo '<script>alert(" به سایت میم وود خوش آمدید")</script>';
        exit;
    } 
    else {
        header("location:login.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fa">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>صفحه ورود</title>
    <link rel="stylesheet" href="../css/login.css" type="text/css" />
</head>

<body class="login">
    <div class="container">
        <div class="login__form">
            <div class="login__form__img">
                <img src="../images/img/wood.jpg" alt="wood" />
            </div>
            <div class="login__form__right">
                <h1>ورود</h1>
                <form action="" method="post" enctype="multipart/form-data">
                    <label for="input-email">
                        <h2>ایمیل</h2>
                    </label>
                    <input type="email" id="input-email" name="email" required />
                    <label for="input-pass">
                        <h2>رمز عبور</h2>
                    </label>
                    <input type="password" id="input-pass" name="pass" required />
                    <button class="login-btn" name="login_btn">
                        <h2>ورود</h2>
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>