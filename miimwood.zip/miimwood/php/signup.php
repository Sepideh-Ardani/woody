<?php
require_once "config.php";

if (isset($_POST['signup_btn'])) {
    $name = $_POST['name'];
    $phone_number = $_POST['tell'];
    $email = $_POST['email'];
    $pass = md5($_POST['pass']);
    $repass = md5($_POST['repass']);
    $address = $_POST['address'];

    if ($pass != $repass) {
        echo '<script>alert("رمز و تکرار رمز مطابقت ندارد")</script>';
    } else {
        $query = "SELECT * FROM customers WHERE cus_email='$email'";
        $stm = $connection->prepare($query);
        $stm->execute();
        $result = $stm->fetch();

        if ($result) {
            echo '<script>alert("ایمیل تکراری است")</script>';
        } else {
            $query = "INSERT INTO customers (cus_name, cus_phone, cus_email, cus_pass,cus_address) 
            VALUES ('$name', '$phone_number', '$email', '$pass', '$address')";
            $stmt = $connection->prepare($query);
            $equal = $stmt->execute();
            if ($equal) {
                echo '<script>alert("اطلاعات شما با موفقیت ثبت شد")</script>';
            } else {
                echo '<script>alert("خطا در ثبت اطلاعات")</script>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" dir="rtl">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ثبت نام</title>
    <link rel="stylesheet" href="../css/signup.css" type="text/css" />
</head>

<body class="signup">
    <div class="container-sign">
        <div class="signup__forms">
            <div class="signup__forms__img">
                <img src="../images/img/wood.jpg" alt="wood" />
            </div>
            <div class="signup__forms__right">
                <h1>عضویت</h1>
                <form action="signup.php" method="post" enctype="multipart/form-data">
                    <label for="input-name">
                        <h2>نام و نام خانوادگی</h2>
                    </label>
                    <input type="text" id="input-name" name="name" required />
                    <label for="input-tell">
                        <h2>تلفن</h2>
                    </label>
                    <input type="number" id="input-tell" name="tell" required />
                    <label for="input-email">
                        <h2>ایمیل</h2>
                    </label>
                    <input type="email" id="input-email" name="email" required />
                    <label for="input-pass">
                        <h2>رمز عبور</h2>
                    </label>
                    <input type="password" id="input-pass" name="pass" required />
                    <label for="input-repass">
                        <h2>تکرار رمز عبور</h2>
                    </label>
                    <input type="password" id="input-repass" name="repass" required />
                    <label for="input-address">
                        <h2>آدرس</h2>
                    </label>
                    <input type="text" id="input-address" name="address" required />
                    <button type="submit" class="signup-btn" name="signup_btn">
                        <h2>ثبت</h2>
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>