<?php
session_start();
if(!isset($_SESSION['user'])){
    header("location:admin.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/admin.css" />
    <title>پنل ادمین</title>
</head>

<body class="admins">
    <main>
        <div class="admin">
            <header>
                <nav>
                    <ul>
                        <li><a href="#"><img src="../images/icon/logo.png" alt="Logo" /></a></li>
                        <li><a href="admin.php">پنل ادمین</a></li>
                        <li><a href="addcontact.php">مدیریت کاربران</a></li>
                        <li>
                            <a href="#">محصولات</a>
                            <div class="menu">
                                <ul>
                                    <li><a href="addproduct.php">افزودن محصولات</a></li>
                                    <li><a href="edit.php">مدیریت محصولات</a></li>
                                </ul>
                            </div>
                        </li>
                        <li><a href="exit.php">خروج</a></li>
                    </ul>
                </nav>
            </header>
        </div>
    </main>
</body>

</html>