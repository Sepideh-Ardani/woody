<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("location:login.php");
    exit();
}

require_once "config.php";

// دریافت دسته‌بندی‌ها
$query = "SELECT * FROM category";
$stmtt = $connection->prepare($query);
$stmtt->execute();
$categories = $stmtt->fetchAll(PDO::FETCH_ASSOC);

$errors = array();
$result = "";
if (isset($_POST['add_btn'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $pic = $_FILES['pic'];
    $desc = $_POST['desc'];
    $statues = $_POST['statues'];
    $cate_id = $_POST['cate_id'];
    
    if ($pic['size'] > 0) {
        $picname = time() . $pic['name'];
        $arr = explode('.', $pic['name']);
        $ext = end($arr);
        if ($ext != 'jpg' && $ext != 'png' && $ext != 'jpeg') {
            $errors[] = "فرمت نامعتبر";
        }
        if ($pic['size'] > 900 * 1024) {
            $errors[] = "سایز بزرگتر از 900 کیلوبایت است";
        }
    } else {
        $picname = "";
    }

    if (count($errors) == 0) {
        if ($pic['size'] > 0) {
            move_uploaded_file($pic['tmp_name'], "../pic/$picname");
        }
        
        $query = "INSERT INTO products (product_name, product_price, product_cover, product_description, product_statues, cate_id) VALUES (:name, :price, :cover, :desc, :statues, :cate_id)";
        $stmtt = $connection->prepare($query);
        $stmtt->bindParam(':name', $name);
        $stmtt->bindParam(':price', $price);
        $stmtt->bindParam(':cover', $picname);
        $stmtt->bindParam(':desc', $desc);
        $stmtt->bindParam(':statues', $statues);
        $stmtt->bindParam(':cate_id', $cate_id);
        $result = $stmtt->execute();
        
        if ($result) {
            echo '<script>alert("اطلاعات با موفقیت ثبت شد")</script>';
        }
    } else {
        foreach ($errors as $error) {
            echo "$error" . "<br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fa">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/addproduct.css" type="text/css" />
    <title>افزودن محصول جدید</title>
</head>

<body class="add">
    <div class="container-add">
        <h2 class="add-h2">افزودن محصول جدید</h2>
        <form action="addproduct.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="product-name">نام محصول:</label>
                <input type="text" id="product-name" name="name" placeholder="نام محصول" required>
            </div>

            <div class="form-group">
                <label for="product-price">قیمت محصول:</label>
                <input type="number" id="product-price" name="price" placeholder="قیمت محصول" required>
            </div>

            <div class="form-group">
                <label for="product-image">عکس محصول:</label>
                <input type="file" id="product-image" name="pic" required>
            </div>

            <div class="form-group">
                <label for="cate_id">دسته‌بندی:</label>
                <select class="form-control" id="cate_id" name="cate_id" required>
                    <option value="">انتخاب کنید</option>
                    <?php foreach ($categories as $category) { ?>
                    <option value="<?php echo htmlspecialchars($category['cate_id']); ?>">
                        <?php echo htmlspecialchars($category['cate_name']); ?>
                    </option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="product-description">توضیحات محصول:</label>
                <textarea id="product-description" name="desc" required></textarea>
            </div>

            <label for="product-statues">وضعیت محصول:</label>
            <select id="product-statues" name="statues" required>
                <option value="1">موجود</option>
                <option value="0">ناموجود</option>
            </select>
            <br>
            <button type="submit" class="add_btn" name="add_btn">ثبت</button>
        </form>
    </div>
</body>

</html>