<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

require_once 'config.php';

if (isset($_GET['id'])) {
    $id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);

    // گرفتن اطلاعات مشتری
    $query = "SELECT * FROM customers WHERE cus_id = :id";
    $stmt = $connection->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $customer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$customer) {
        die('مشتری یافت نشد');
    }

    if (isset($_POST['btn_update'])) {
        $errors = [];

        // اعتبارسنجی داده‌ها
        if (empty($_POST['cus_name'])) {
            $errors[] = "نام نمی‌تواند خالی باشد";
        }
        if (empty($_POST['cus_phone'])) {
            $errors[] = "تلفن نمی‌تواند خالی باشد";
        }
        if (empty($_POST['cus_email'])) {
            $errors[] = "ایمیل نمی‌تواند خالی باشد";
        }
        if (empty($_POST['cus_pass'])) {
            $errors[] = "رمز عبور نمی‌تواند خالی باشد";
        }
        if (empty($_POST['cus_address'])) {
            $errors[] = "آدرس نمی‌تواند خالی باشد";
        }

        // بروز رسانی مشتری در دیتابیس
        if (empty($errors)) {
            $hashed_password = md5($_POST['cus_pass']); // هش کردن رمز عبور با استفاده از md5

            $query = "UPDATE customers SET 
                cus_name = :cus_name,
                cus_phone = :cus_phone,
                cus_email = :cus_email,
                cus_pass = :cus_pass,
                cus_address = :cus_address 
                WHERE cus_id = :id";
            $stmt = $connection->prepare($query);
            $stmt->bindParam(":cus_name", $_POST['cus_name'], PDO::PARAM_STR);
            $stmt->bindParam(":cus_phone", $_POST['cus_phone'], PDO::PARAM_STR);
            $stmt->bindParam(":cus_email", $_POST['cus_email'], PDO::PARAM_STR);
            $stmt->bindParam(":cus_pass", $hashed_password, PDO::PARAM_STR);
            $stmt->bindParam(":cus_address", $_POST['cus_address'], PDO::PARAM_STR);
            $stmt->bindParam(":id", $_POST['id'], PDO::PARAM_INT);
            $stmt->execute();

            // افزودن پیغام موفقیت به $_SESSION
            $_SESSION['success_message'] = 'اطلاعات با موفقیت ویرایش شد';

            header("Location: updatecontact.php?id=" . $id);
            exit();
        } else {
            foreach ($errors as $error) {
                echo "<p>$error</p>";
            }
        }
    }
} else {
    die('آیدی مشتری مشخص نشده');
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ویرایش مشتری</title>
    <link rel="stylesheet" href="../style/bootstrap.rtl.min.css" />
    <style>
    .container-update {
        background: rgba(255, 255, 255, 0.8);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-radius: 10px;
        padding: 30px;
        max-width: 500px;
        margin: auto;
        margin-top: 50px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .update-h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    .form-label {
        color: #333;
    }

    .update_btn {
        background-color: #4D869C;
        color: #fff;
        width: 100%;
        padding: 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .update_btn:hover {
        background-color: #7AB2B2;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }
    </style>
</head>

<body>
    <div class="container-update">
        <h2 class="update-h2">ویرایش مشتری</h2>
        <?php
        if (isset($_SESSION['success_message'])) {
            echo '<p style="color: green;">' . $_SESSION['success_message'] . '</p>';
            unset($_SESSION['success_message']);
        }
        ?>
        <form action="updatecontact.php?id=<?php echo htmlspecialchars($customer['cus_id']); ?>" method="post">
            <input type="hidden" id="id" name="id" value="<?php echo htmlspecialchars($customer['cus_id']); ?>">
            <div class="mb-4 form-group">
                <label for="cus_name" class="form-label">نام</label>
                <input type="text" class="form-control" id="cus_name" name="cus_name"
                    value="<?php echo htmlspecialchars($customer['cus_name']); ?>">
            </div>
            <div class="mb-4 form-group">
                <label for="cus_phone" class="form-label">تلفن</label>
                <input type="text" class="form-control" id="cus_phone" name="cus_phone"
                    value="<?php echo htmlspecialchars($customer['cus_phone']); ?>">
            </div>
            <div class="mb-4 form-group">
                <label for="cus_email" class="form-label">ایمیل</label>
                <input type="email" class="form-control" id="cus_email" name="cus_email"
                    value="<?php echo htmlspecialchars($customer['cus_email']); ?>">
            </div>
            <div class="mb-4 form-group">
                <label for="cus_pass" class="form-label">رمز عبور</label>
                <input type="text" class="form-control" id="cus_pass" name="cus_pass"
                    value="<?php echo htmlspecialchars($customer['cus_pass']); ?>">
            </div>
            <div class="mb-4 form-group">
                <label for="cus_address" class="form-label">آدرس</label>
                <textarea class="form-control" id="cus_address"
                    name="cus_address"><?php echo htmlspecialchars($customer['cus_address']); ?></textarea>
            </div>
            <div class="mb-4 form-group">
                <input type="submit" name="btn_update" value="به‌روزرسانی" class="update_btn">
            </div>
        </form>
    </div>
</body>

</html>