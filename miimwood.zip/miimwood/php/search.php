<?php
require_once('config.php');

if (isset($_GET['query'])) {
    $query = $_GET['query'];
    $searchTerm = "%" . $query . "%";

    // استفاده از پرسش‌نامه آماده برای جلوگیری از SQL Injection
    $sql = "SELECT * FROM products WHERE product_name LIKE :searchTerm";
    $stmt = $connection->prepare($sql);

    // بایند کردن پارامتر
    $stmt->bindParam(':searchTerm', $searchTerm, PDO::PARAM_STR);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/search.css" type="text/css" />
    <title>نتایج جستجو</title>
</head>

<body>
    <h1>نتایج جستجو برای: <?php echo htmlspecialchars($query); ?></h1>
    <div class="results">
        <?php
        if (count($results) > 0) {
            foreach ($results as $row) {
                echo "<div class='product'>";
                echo "<h2>" . htmlspecialchars($row['product_name']) . "</h2>";
                echo "<p>قیمت: " . htmlspecialchars($row['product_price']) . " تومان</p>";
                if (!empty($row['product_cover'])) {
                    echo "<img src='../pic/" . htmlspecialchars($row['product_cover']) . "' alt='" . htmlspecialchars($row['product_name']) . "'>";
                }
                echo "<p>" . htmlspecialchars($row['product_description']) . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>هیچ نتیجه‌ای یافت نشد.</p>";
        }
        ?>
    </div>
</body>

</html>

<?php
} else {
    echo "<h1>لطفا یک عبارت برای جستجو وارد کنید.</h1>";
}
?>