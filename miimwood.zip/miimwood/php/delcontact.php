<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    
}

require_once 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // کوئری حذف
    $query = "DELETE FROM customers WHERE cus_id = :id";
    
    // آماده سازی و اجرای کوئری
    $stmt = $connection->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    if ($stmt->execute()) {
        header("Location: addcontact.php"); // بازگشت به صفحه مدیریت محصولات
        
    } else {
        echo "خطایی رخ داده است. لطفاً دوباره تلاش کنید.";
    }
} else {
    echo "شناسه کاربر نامعتبر است.";
}
?>