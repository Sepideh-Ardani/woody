<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

require_once 'config.php';

if (isset($_GET['id'])) {
    $id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);

    // گرفتن اطلاعات محصول
    $query = "SELECT * FROM products WHERE product_id = :id";
    $stmt = $connection->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        die('محصول یافت نشد');
    }

    // گرفتن لیست دسته‌بندی‌ها
    $query = "SELECT * FROM category";
    $stmt = $connection->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (isset($_POST['btn_update'])) {
        $errors = [];

        // اعتبارسنجی داده‌ها
        if (empty($_POST['name'])) {
            $errors[] = "نام محصول نمی‌تواند خالی باشد";
        }
        
        // مدیریت فایل تصویر
        $cover = $_FILES['pic'];
        if (empty($cover['name'])) {
            $picname = $_POST['coverpre'];
        } else {
            $allowedTypes = ["image/png", "image/jpg", "image/jpeg"];
            if (in_array($cover['type'], $allowedTypes)) {
                if ($cover['size'] < 900 * 1024) {
                    $picname = time() . '_' . $cover['name'];
                    if (!move_uploaded_file($cover['tmp_name'], "../pic/$picname")) {
                        $errors[] = "مشکل در آپلود";
                    }
                } else {
                    $errors[] = "سایز نامناسب";
                }
            } else {
                $errors[] = "فرمت نامناسب";
            }
        }

        // بروز رسانی محصول در دیتابیس
        if (empty($errors)) {
            $query = "UPDATE products SET 
                product_name = :name,
                product_price = :price,
                product_cover = :pic,
                product_description = :desc,
                product_statues = :statues,
                cate_id = :cate_id 
                WHERE product_id = :id";
            $stmt = $connection->prepare($query);
            $stmt->bindParam(":name", $_POST['name'], PDO::PARAM_STR);
            $stmt->bindParam(":statues", $_POST['statues'], PDO::PARAM_INT);
            $stmt->bindParam(":pic", $picname, PDO::PARAM_STR);
            $stmt->bindParam(":price", $_POST['price'], PDO::PARAM_INT);
            $stmt->bindParam(":desc", $_POST['desc'], PDO::PARAM_STR);
            $stmt->bindParam(":cate_id", $_POST['cate_name'], PDO::PARAM_INT);
            $stmt->bindParam(":id", $_POST['id'], PDO::PARAM_INT);
            $stmt->execute();

            // افزودن پیغام موفقیت به $_SESSION
            $_SESSION['success_message'] = 'اطلاعات با موفقیت ویرایش شد';

            header("Location: update.php?id=" . $id);
            exit();
        } else {
            foreach ($errors as $error) {
                echo "<p>$error</p>";
            }
        }
    }
} else {
    die('آیدی محصول مشخص نشده');
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ویرایش محصول</title>
    <link rel="stylesheet" href="../style/bootstrap.rtl.min.css" />
    <style>
    @font-face {
        font-family: "Vazir-Bold";
        src: url("https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/Vazir-Bold.woff2") format("woff2");
    }

    body {
        background: url('../images/img/photo12744071959.jpg') no-repeat center center fixed;
        background-size: cover;
        height: 100vh;
        margin: 0;
        direction: rtl;
        font-family: Vazir-Bold;
    }

    .container-update {
        background: rgba(255, 255, 255, 0.8);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-radius: 10px;
        padding: 30px;
        max-width: 500px;
        margin: auto;
        margin-top: 50px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .update-h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    .form-label {
        color: #333;
    }

    .update_btn {
        background-color: #4D869C;
        color: #fff;
        width: 100%;
        padding: 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-family: Vazir-Bold;
    }

    .update_btn:hover {
        background-color: #7AB2B2;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    .img-fluid {
        max-width: 300px;
        max-height: 300px;
        display: block;
        margin: 20px auto;
    }
    </style>
</head>

<body>
    <div class="container-update">
        <h2 class="update-h2">ویرایش محصول</h2>
        <?php
        if (isset($_SESSION['success_message'])) {
            echo '<p style="color: green;">' . $_SESSION['success_message'] . '</p>';
            unset($_SESSION['success_message']);
        }
        ?>
        <form action="update.php?id=<?php echo htmlspecialchars($product['product_id']); ?>" method="post"
            enctype="multipart/form-data">
            <input type="hidden" id="id" name="id" value="<?php echo htmlspecialchars($product['product_id']); ?>">
            <input type="hidden" id="coverpre" name="coverpre"
                value="<?php echo htmlspecialchars($product['product_cover']); ?>">
            <div class="mb-4 form-group">
                <label for="name" class="form-label">نام محصول</label>
                <input type="text" class="form-control" id="name" name="name"
                    value="<?php echo htmlspecialchars($product['product_name']); ?>">
            </div>
            <div class="mb-4 form-group">
                <label for="cate_name" class="form-label">دسته‌بندی</label>
                <select class="form-select" id="cate_name" name="cate_name">
                    <?php foreach ($categories as $category) {
                        $selected = $product['cate_id'] == $category['cate_id'] ? 'selected' : '';
                        echo '<option value="' . htmlspecialchars($category['cate_id']) . '" ' . $selected . '>' . htmlspecialchars($category['cate_name']) . '</option>';
                    } ?>
                </select>
            </div>
            <div class="mb-4 form-group">
                <label for="statues" class="form-label">وضعیت</label>
                <input type="number" class="form-control" id="statues" name="statues"
                    value="<?php echo htmlspecialchars($product['product_statues']); ?>">
            </div>
            <div class="mb-4 form-group">
                <label for="price" class="form-label">قیمت</label>
                <input type="number" class="form-control" id="price" name="price"
                    value="<?php echo htmlspecialchars($product['product_price']); ?>">
            </div>
            <div class="mb-4 form-group">
                <label for="pic" class="form-label">فایل</label>
                <input type="file" class="form-control" id="pic" name="pic">
            </div>
            <div class="mb-4 form-group">
                <label for="desc" class="form-label">توضیحات</label>
                <textarea class="form-control" id="desc"
                    name="desc"><?php echo htmlspecialchars($product['product_description']); ?></textarea>
            </div>
            <div class="mb-4 form-group">
                <input type="submit" name="btn_update" value="به‌روزرسانی" class="update_btn">
            </div>
        </form>
        <?php if (!empty($product['product_cover'])): ?>
        <img src="../pic/<?php echo htmlspecialchars($product['product_cover']); ?>" alt="Product Cover"
            class="img-fluid">
        <?php endif; ?>
    </div>
</body>

</html>